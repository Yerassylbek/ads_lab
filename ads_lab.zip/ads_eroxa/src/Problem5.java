import java.util.Scanner;

public class Problem5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int num = scanner.nextInt();
        System.out.println(Fibonacci(num));

    }
    public static int Fibonacci(int num){
        if(num <= 1){
            return  num;
        }
        else
            return  Fibonacci(num - 1) + Fibonacci(num - 2);
    }
}
