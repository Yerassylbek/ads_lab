import java.util.Scanner;

public class Problem2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int length = scanner.nextInt();
        int [] array = new int[length];
        System.out.println(averageArray(array));

    }

    public static float averageArray(int [] array){
        Scanner scanner = new Scanner(System.in);
        float sum = 0, counter = 0;
        for(int i = 0; i < array.length; i++){
            array[i] = scanner.nextInt();
            sum += array[i];
            counter++;
        }

        return sum / counter;
    }
}
