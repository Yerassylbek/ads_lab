import java.util.Scanner;

public class Problem8 {
    public static void main(String[] args) {
        Scanner scanner =  new Scanner(System.in);
        String myString = scanner.next();
        if(isITNumber(myString)){
            System.out.println("YES");
        }
        else
            System.out.println("NO");
    }

    public static boolean isITNumber(String myString){
        for(int i = 0; i < myString.length(); i++){
            if(Character.isDigit(myString.charAt(i)) == false){
                return  false;
            }
        }
        return  true;
    }
}
