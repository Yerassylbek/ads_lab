import java.util.Scanner;

public class Problem1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int length = scanner.nextInt();
        int [] array = new int[length];
        System.out.println(minArray(array));


    }
    public static int minArray(int [] array){
        Scanner scanner = new Scanner(System.in);
        int min = Integer.MAX_VALUE;
        for(int i = 0; i < array.length; i++){
            array[i] = scanner.nextInt();
            if(array[i] < min){
                min = array[i];
            }
        }

        return min;
    }
}
