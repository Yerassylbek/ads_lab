import java.util.Scanner;

public class Problem7 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int length = scanner.nextInt();
        int[] arr= new int[length];
        for(int i = 0; i < arr.length; i++){
            arr[i] = scanner.nextInt();
        }
        int size = arr.length;
        int[] reverseArray = reverseArray(arr,0,size-1);


        for(int i: reverseArray)
            System.out.print(i+" ");

    }
    public static int[] reverseArray(int[] a,int start,int size){

        if(start < size){

            //swapping elements
            int temp=a[start];
            a[start]=a[size];
            a[size]=temp;

            reverseArray(a, start + 1, size-1);
        }

        return a;
    }
}