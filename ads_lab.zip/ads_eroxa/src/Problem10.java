import java.util.Scanner;

public class Problem10 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int a = scanner.nextInt();
        int b = scanner.nextInt();

        System.out.println( GCD(a, b));

    }
    static int GCD(int a, int b) {
        if (a == b) {
            return a;
        }
        int PrimeA = Math.max(a, b) - Math.min(a, b);
        int PrimeB = Math.min(a, b);
        return GCD(PrimeA, PrimeB);
    }
}